<?php

namespace Pterodactyl\Exceptions\Service\Helper;

class CdnVersionFetchingException extends \Exception
{
}
